# H-GEO 1.2.3 — plugin experimental para QGIS

## Instalação

1. Abra QGIS 3.40.
2. Acesse **Complementos → Gerenciar e Instalar Complementos → Instalar a partir do ZIP**.
3. Selecione `HGEO_1.2.3.zip` e clique em **Instalar complemento**.
4. Use **Complementos → H-GEO → Abrir H-GEO**, ou o botão na barra de ferramentas.

Feche a versão executada como script antes de usar o plugin, para evitar janelas duplicadas.

## Funções preservadas

Modos Operacional e Analista; camada de rascunho; buffer; análise multiespectral; download de bandas e MDE; reprojeção; extração de exutório; delimitação de bacia; drenagem; prévias e relatório comparativo em PDF.

Os algoritmos existentes foram mantidos. O código original foi integrado em `legacy.py`; esta versão ainda não representa uma separação completa dos módulos internos.

## Melhorias

- Integração com o ciclo de carregamento e desativação do QGIS.
- Importação das ferramentas somente no primeiro uso, sem abrir janelas na inicialização do QGIS.
- Atalhos diretos para modos e relatório.
- Reutilização da janela ao abrir novamente o mesmo modo.
- Imports Qt pela camada `qgis.PyQt`.
- Remoção dos menus e ocultação das janelas ao desativar. Threads em execução não são encerradas à força; operações existentes podem continuar até concluir.

## Validação e limites

Testado com bibliotecas reais do QGIS 3.40.15 em execução sem interface visível e com uma interface hospedeira simulada: importação, carregamento sob demanda, quatro ações, abertura dos dois modos e do relatório, reutilização da janela, desativação e cálculo NDVI com zero no denominador/NoData.

Foram gerados relatórios completos com dados sintéticos em português e inglês. Não foram executados downloads ou fluxos completos GRASS/GDAL com dados reais nesta validação. As operações dependem da conexão de rede, cobertura dos serviços e provedores Processing já exigidos pelo script original. Não há medição de ganho de tempo no processamento raster; as melhorias desta versão concentram-se no carregamento e nas janelas.

Compatibilidade declarada: QGIS 3.40 a 3.x; QGIS 4 não validado. Distribuição local experimental; publicação no repositório oficial exige definir licença, autoria, contato e repositório com o responsável.

Estrutura de plugin baseada na documentação oficial: https://docs.qgis.org/3.40/en/docs/pyqgis_developer_cookbook/plugins/plugins.html


## Português e inglês — versão 1.2.3

Por padrão, o plugin acompanha o idioma do QGIS. O botão Idioma permite escolher um idioma próprio para o H-GEO. Inglês (en_US/en_GB e variantes) ativa a tradução; português e idiomas sem catálogo usam os textos originais. Para mudar apenas o H-GEO, use Idioma → English ou Português → Salvar. Para mudar o idioma de todo o QGIS, use Configurações → Opções → Geral → Localidade e reinicie o QGIS.

Foram traduzidos menus, janelas, mensagens, nove guias, explicações dos índices, prévias e relatórios PDF. Identificadores internos, nomes fornecidos pelo usuário, arquivos de saída e campos como CLASSE foram preservados. Os relatórios em inglês usam ponto decimal na tabela e no resumo; os valores dos dados não mudam.

Validação adicional desta versão: QGIS 3.40.15 sem interface hospedeira real, todos os nove guias, os 12 índices comparados numericamente ao código original e relatórios completos com entradas sintéticas em português e inglês (15 páginas, 36 GeoTIFFs, estatísticas e proveniência por idioma). O PDF inglês foi renderizado para revisão visual. Downloads reais e processamento GRASS completo continuam fora dessa validação.

Este pacote é uma compilação local experimental; ainda não foi publicado como release no GitHub. Instruções em inglês: README_EN.md.

## Botão Idioma

Use Idioma na tela inicial, em Complementos → H-GEO → Idioma. Escolha Português, English ou Acompanhar o QGIS. Clique em Salvar: a interface aberta muda imediatamente. A preferência fica salva sem mudar o idioma do próprio QGIS. A troca aguarda o término de processamentos ativos; campos e seleções são preservados. O histórico já registrado permanece no idioma em que foi produzido. Cancelar mantém a escolha anterior.
