import json
import re
import weakref
from string import Formatter
from pathlib import Path

from qgis.core import QgsApplication
from qgis.PyQt.QtCore import QLocale, QSettings


_language = None
_english = json.loads((Path(__file__).parent / 'translations' / 'en.json').read_text(encoding='utf-8'))


def set_language(locale=None):
    global _language
    preference = QSettings().value('hgeo/language', 'auto', type=str)
    locale = locale or (preference if preference in ('pt', 'en') else None) or QgsApplication.locale() or QLocale.system().name()
    _language = 'en' if str(locale).replace('-', '_').split('_')[0].lower() == 'en' else 'pt'
    return _language


def tr(text):
    if _language is None:
        set_language()
    return _english.get(text, text) if _language == 'en' else text


_SOURCE_ROLE = 329


def add_choices(combo, values):
    for value in values:
        combo.addItem(tr(value))
        combo.setItemData(combo.count() - 1, value, _SOURCE_ROLE)


def choice_text(combo):
    source = combo.currentData(_SOURCE_ROLE)
    return source if source is not None else combo.currentText()


def trf(text, *values):
    return tr(text).format(*values)


def format_number(value, precision=4):
    formatted = format(value, '.' + str(precision) + 'f')
    if _language is None:
        set_language()
    return formatted if _language == 'en' else formatted.replace('.', ',')


def show_language_dialog(parent=None):
    from qgis.PyQt.QtWidgets import QComboBox, QDialog, QDialogButtonBox, QLabel, QVBoxLayout

    dialog = QDialog(parent)
    dialog.setWindowTitle(tr('Idioma do H-GEO'))
    dialog.setMinimumWidth(360)
    layout = QVBoxLayout(dialog)
    layout.addWidget(QLabel(tr('Escolha o idioma da interface e dos relatórios:')))
    choices = QComboBox(dialog)
    choices.setObjectName('hgeo-language-choice')
    for label, value in ((tr('Acompanhar o QGIS'), 'auto'), ('Português', 'pt'), ('English', 'en')):
        choices.addItem(label, value)
    settings = QSettings()
    current = choices.findData(settings.value('hgeo/language', 'auto', type=str))
    choices.setCurrentIndex(max(0, current))
    layout.addWidget(choices)
    notice = QLabel(tr('O idioma será atualizado assim que você salvar. Campos preenchidos e seleções serão mantidos.'))
    notice.setWordWrap(True)
    layout.addWidget(notice)
    buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel, parent=dialog)
    buttons.button(QDialogButtonBox.Save).setText(tr('Salvar'))
    buttons.button(QDialogButtonBox.Cancel).setText(tr('Cancelar'))
    buttons.accepted.connect(dialog.accept)
    buttons.rejected.connect(dialog.reject)
    layout.addWidget(buttons)
    if dialog.exec_() == QDialog.Accepted:
        if language_busy():
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.information(parent, tr('Idioma do H-GEO'), tr('Aguarde o processamento terminar antes de trocar o idioma.'))
            return False
        apply_language(choices.currentData(), settings)
        return True
    return False


def create_language_button(parent=None, subtle=False):
    from qgis.PyQt.QtCore import QSize, Qt
    from qgis.PyQt.QtGui import QIcon
    from qgis.PyQt.QtWidgets import QPushButton

    button = QPushButton(tr('Idioma'), parent)
    button.setObjectName('hgeo-language-button')
    button.setIcon(QIcon(str(Path(__file__).parent / 'globe.svg')))
    button.setIconSize(QSize(18, 18))
    button.setCursor(Qt.PointingHandCursor)
    button.setToolTip(tr('Idioma do H-GEO'))
    button.setStyleSheet(
        'QPushButton { background-color: #eef4fa; color: #1e507e; '
        'border: 1px solid #c4d6e6; border-radius: 6px; padding: 6px 10px; '
        'font-size: 12px; font-weight: 600; min-height: 20px; } '
        'QPushButton:hover { background-color: #ddeaf5; color: #153a5b; border-color: #8aafcf; } '
        'QPushButton:pressed { background-color: #ccdfef; color: #153a5b; } '
        'QPushButton:focus { border: 2px solid #1e507e; padding: 5px 9px; }'
    )
    if subtle:
        button.setIconSize(QSize(15, 15))
        button.setStyleSheet(
            'QPushButton { background-color: transparent; color: #365f80; '
            'border: 1px solid transparent; border-radius: 4px; padding: 4px 6px; '
            'font-size: 11px; font-weight: 400; min-height: 18px; } '
            'QPushButton:hover { background-color: #eaf1f7; color: #1e507e; } '
            'QPushButton:pressed { background-color: #dce8f2; } '
            'QPushButton:focus { border-color: #8aafcf; }'
        )
    return button


_runtime_namespaces = []
_language_actions = []
_reverse_english = {}
for _source_text, _target_text in _english.items():
    _reverse_english.setdefault(_target_text, _source_text)


def register_language_action(action, source):
    _language_actions.append((weakref.ref(action), source))


def register_runtime(namespace):
    if not any(item is namespace for item in _runtime_namespaces):
        _runtime_namespaces.append(namespace)


def _translate_existing(text, previous):
    if not text:
        return text
    source = _reverse_english.get(text, text) if previous == 'en' else text
    if source in _english:
        return tr(source)
    for source_template, english_template in _english.items():
        if not re.search(r'\{\d+', source_template):
            continue
        old_template = english_template if previous == 'en' else source_template
        pieces = []
        fields = []
        for literal, field, spec, conversion in Formatter().parse(old_template):
            pieces.append(re.escape(literal))
            if field is not None:
                pieces.append('(.*?)')
                fields.append(int(field))
        match = re.fullmatch(''.join(pieces), text, re.DOTALL)
        if not match:
            continue
        values = dict(zip(fields, match.groups()))
        result = []
        for literal, field, spec, conversion in Formatter().parse(tr(source_template)):
            result.append(literal)
            if field is not None:
                result.append(values[int(field)])
        return ''.join(result)
    percent = re.compile(r'%(?:[-+0#]*\d*(?:\.\d+)?[sdfgri]|%)')
    for source_template, english_template in _english.items():
        old_template = english_template if previous == 'en' else source_template
        tokens = list(percent.finditer(old_template))
        if not any(token.group() != '%%' for token in tokens):
            continue
        pieces = []
        start = 0
        for token in tokens:
            pieces.append(re.escape(old_template[start:token.start()]))
            pieces.append('%' if token.group() == '%%' else '(.*?)')
            start = token.end()
        pieces.append(re.escape(old_template[start:]))
        match = re.fullmatch(''.join(pieces), text, re.DOTALL)
        if match:
            values = iter(match.groups())
            return percent.sub(lambda token: '%' if token.group() == '%%' else next(values), tr(source_template))
    return text


def _translate_values(value, previous):
    if isinstance(value, str):
        return _translate_existing(value, previous)
    if isinstance(value, tuple):
        return tuple(_translate_values(item, previous) for item in value)
    if isinstance(value, list):
        value[:] = [_translate_values(item, previous) for item in value]
        return value
    if isinstance(value, dict):
        for key in value:
            if key != 'palavras':
                value[key] = _translate_values(value[key], previous)
    return value


def _plugin_widgets():
    from qgis.PyQt.QtWidgets import QApplication, QWidget

    widgets = set()
    for root in QApplication.allWidgets():
        if type(root).__module__.startswith(__package__ + '.'):
            widgets.add(root)
            widgets.update(root.findChildren(QWidget))
    return widgets


def language_busy():
    from qgis.PyQt.QtCore import QThread

    for widget in _plugin_widgets():
        if any(worker.isRunning() for worker in widget.findChildren(QThread)):
            return True
        task = getattr(widget, '_task', None)
        if task is not None and task.isActive():
            return True
    return False


def apply_language(preference, settings=None):
    from qgis.PyQt.QtWidgets import QAbstractButton, QComboBox, QGroupBox, QLabel, QLineEdit, QDateEdit, QSpinBox, QDoubleSpinBox, QListWidget

    if preference not in ('auto', 'pt', 'en'):
        raise ValueError('Unsupported language preference')
    if language_busy():
        return False
    if _language is None:
        set_language()
    previous = _language
    settings = settings if settings is not None else QSettings()
    settings.setValue('hgeo/language', preference)
    settings.sync()
    locale = (QgsApplication.locale() or QLocale.system().name()) if preference == 'auto' else preference
    set_language(locale)
    if previous == _language:
        return True
    for namespace in _runtime_namespaces:
        details = namespace.get('HGR_INDEX_DETAILS', {})
        for key, (title, english, meaning) in details.items():
            details[key] = (_translate_existing(title, previous), english, _translate_existing(meaning, previous))
        indices = namespace.get('HGR_INDICES', {})
        for key, (title, bands, formula) in indices.items():
            indices[key] = (_translate_existing(title, previous), bands, formula)
        if 'HGR_SOURCES' in namespace:
            namespace['HGR_SOURCES'] = [(_translate_existing(title, previous), url)
                                        for title, url in namespace['HGR_SOURCES']]
        laboratory = namespace.get('AnaliseMultiespectralDialog')
        if laboratory is not None:
            laboratory.NOMES_BANDAS_PT = _translate_values(laboratory.NOMES_BANDAS_PT, previous)
    for widget in _plugin_widgets():
        widget.setWindowTitle(_translate_existing(widget.windowTitle(), previous))
        widget.setToolTip(_translate_existing(widget.toolTip(), previous))
        if isinstance(widget, (QAbstractButton, QLabel)):
            widget.setText(_translate_existing(widget.text(), previous))
        elif isinstance(widget, QGroupBox):
            widget.setTitle(_translate_existing(widget.title(), previous))
        elif isinstance(widget, QLineEdit):
            widget.setPlaceholderText(_translate_existing(widget.placeholderText(), previous))
        elif isinstance(widget, QComboBox):
            blocked = widget.blockSignals(True)
            try:
                for index in range(widget.count()):
                    source = widget.itemData(index, _SOURCE_ROLE)
                    if source is not None:
                        widget.setItemText(index, tr(source))
                    elif widget.itemData(index) is not None:
                        widget.setItemText(index, _translate_existing(widget.itemText(index), previous))
            finally:
                widget.blockSignals(blocked)
        if isinstance(widget, QDateEdit):
            widget.setDisplayFormat(_translate_existing(widget.displayFormat(), previous))
        elif isinstance(widget, (QSpinBox, QDoubleSpinBox)):
            widget.setSuffix(_translate_existing(widget.suffix(), previous))
            widget.setPrefix(_translate_existing(widget.prefix(), previous))
        elif isinstance(widget, QListWidget):
            blocked = widget.blockSignals(True)
            try:
                for index in range(widget.count()):
                    item = widget.item(index)
                    item.setText(_translate_existing(item.text(), previous))
            finally:
                widget.blockSignals(blocked)
        checks = getattr(widget, 'checks', None)
        if checks is not None:
            for namespace in _runtime_namespaces:
                for key, check in checks.items():
                    if key in namespace.get('HGR_INDICES', {}):
                        check.setText(key + ' - ' + namespace['HGR_INDICES'][key][0])
        for name in ('ROTINAS_GUIADAS', 'BASE_DE_CONHECIMENTO'):
            value = getattr(widget, name, None)
            if value is not None:
                _translate_values(value, previous)
        summary = getattr(widget, 'lbl_resumo_indice', None)
        if summary is not None:
            summary.setText(trf('Categoria: <b>{0}</b> — Índice: <b>{1}</b>',
                                widget.combo_cat.currentText(), widget.combo_analise.currentText()))
    surviving = []
    for reference, source in _language_actions:
        action = reference()
        if action is not None:
            try:
                action.setText(tr(source))
                surviving.append((reference, source))
            except RuntimeError:
                pass
    _language_actions[:] = surviving
    return True
