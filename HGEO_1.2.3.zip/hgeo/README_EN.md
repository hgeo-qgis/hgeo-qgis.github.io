# H-GEO 1.2.3 — English / Português

Experimental bilingual build for QGIS 3.40–3.x. QGIS 4 has not been validated.

## Install

In QGIS, open Plugins → Manage and Install Plugins → Install from ZIP, then select HGEO_1.2.3.zip. Use Plugins → H-GEO → Open H-GEO.

By default, the interface follows the QGIS application language. The Language button lets you override it for H-GEO only. English variants such as en_US and en_GB use English; Portuguese and unsupported languages use the original Portuguese text. To use English in H-GEO, click Language → English → Save. To change the language of the whole QGIS application instead, use Settings → Options → General → Locale and restart QGIS. A single installation supports both languages.

Translated content includes menus, dialogs, processing messages, educational guides, index explanations, previews and comparative PDF reports. Source identifiers, user-provided layer names, algorithm IDs, output filenames, field names and data formats are retained to preserve compatibility. Brazilian identifiers and institutions such as APP, SISLA, CNPJ, CLASSE and SIRGAS retain their names.

## Validation

Validated with real QGIS 3.40.15 libraries in an offscreen host: Portuguese and English UI, geometry types, buffer units and end caps, seven analysis categories, all nine guides and action dispatch. All twelve analytical index results matched the original code on deterministic synthetic arrays, including NoData.

Generated complete synthetic reports in both languages, including 15-page PDFs, 36 GeoTIFFs, CSV statistics and JSON provenance for each language. The English PDF was rendered and inspected. No live satellite downloads or complete GRASS watershed processing with real data were performed for this translation build.

The English catalog is hgeo/translations/en.json. Translation helpers are in hgeo/i18n.py. Translated choices retain source values separately from displayed labels.

This archive is a local build, not a published GitHub release. Existing licensing and redistribution terms remain unchanged.

## Language button

Use Language in the welcome screen, Plugins → H-GEO → Language. Choose Português, English or Follow QGIS, then Save. The open interface updates immediately. The preference is saved independently of the QGIS interface language. Cancel leaves it unchanged.

## Live language switching — 1.2.3

Saving a language updates open H-GEO controls, menus and report labels immediately, while preserving entered values, selections and active guide progress. Existing log entries and files retain their original language. Wait for active processing to finish before switching. The QGIS application language is unchanged.
